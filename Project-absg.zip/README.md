# Project-absg
Another Basic Strategy Game, egy egyszerű, terminalos stratégiai játék

Hogyan kell compile-olni
1. IntelliJ IDEA
   1. Megnyitod a játék mappáját IntelliJ-en belül
   2. Fent a kalapáccsal buildeled
2. Terminálos megoldás
   1. Megnyitod a játék mappáját a terminálban
   2. javac Main.java

A compile-olt Main class file-t a "java Main" paranccsal nyithatod meg.

A játék főbb részei:

Egységek:
-
- Földműves : Egy sima munkás, mit vártál?
- Íjász : Az íjának a hatótávja határtalan!
- Griffmadár : Kemény mint a tegnapi tescos kifli, mindenkinek is visszavág!
- Creeper: ssssssssssssssssssssssssssssssssssss BOOM!

Varázslatok:
-
- Villám : Az ítéletnap lecsapott az egységre!
- Tűzlabda : Úristen, egy hatalmas kőkocka ami lángol!
- Feltámasztás : Nehogy azt hidd, hogy vége a csatának!
- Atombomba : Sugárvédő felszerelés ajánlott!
